Drop Database if exists Dentist;
Show databases;
create database Dentist;
Use Dentist;
Show Tables;
  
Drop table if exists Appointment;
Drop table if exists Patient;
Drop table if exists Payment;
Drop table if exists Bill;
Drop table if exists Specialist;
Drop table if exists Treatment;



create table Patient ( 
	patient_id INT NOT NULL,
	fullname VARCHAR(30) NOT NULL,
	address VARCHAR(30) NOT NULL,
	contact_number INT NOT NULL,
	picture LONGBLOB DEFAULT NULL,
	picture_loc VARCHAR(50) DEFAULT NULL,
	PRIMARY KEY (patient_id) 	
);

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(111, 'Joseph Griffith', '13 Sideroad Terrace', 123456, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude1.jpg'),'\Dude1.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(112, 'Ronald Griffith', '14 Sideroad Terrace', 123455, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude2.jpg'),'\Dude2.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(113, 'Reginald Griffith', '15 Sideroad Terrace', 123454, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude3.jpg'),'\Dude3.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(114, 'Josh Griffith', '16 Sideroad Terrace', 123453, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude4.jpg'),'\Dude4.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(115, 'Dave Griffith', '17 Sideroad Terrace', 123452, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude5.jpg'),'\Dude5.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(116, 'Mark Griffith', '18 Sideroad Terrace', 123451, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude6.jpg'),'\Dude6.jpg');

INSERT INTO Patient(patient_id, fullname, address, contact_number,picture, picture_loc)
VALUES(117, 'Andre Griffith', '19 Sideroad Terrace', 123450, load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Dude7.jpg'),'\Dude7.jpg');



create table Appointment ( 
	appointment_id int unsigned NOT NULL AUTO_INCREMENT,
	booking_method ENUM ('Post', 'Phone Call', 'Booked in Practice'),
	patient_id int unsigned NOT NULL,
	treatment ENUM ('Filling', 'Whitening', 'Extraction', 'Root canal', 'Crown') DEFAULT NULL,
	appointment_date_time DATE not null,
	picture LONGBLOB DEFAULT NULL,
	picture_loc VARCHAR(50) DEFAULT NULL,
	primary key (appointment_id),
	FOREIGN KEY (patient_id) REFERENCES Patient(patient_id) ON UPDATE CASCADE ON DELETE CASCADE
	
		
);

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time,picture, picture_loc)
VALUES (1234, 'Post', 111, 'Filling', '2019-11-20', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Filling.jpg'),'\Filling.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time,picture, picture_loc)
VALUES (4567, 'Phone Call', 112, 'Extraction', '2019-11-21', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Extraction.jpg'),'\Extraction.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time,picture, picture_loc)
VALUES (5678, 'Phone Call', 113, 'Filling', '2019-11-21', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Filling.jpg'),'\Filling.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time, picture, picture_loc)
VALUES (6789, 'Booked in Practice', 114, 'Root canal', '2019-11-22', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\RootCanal.jpg'),'\RootCanal.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time, picture, picture_loc)
VALUES (9876, 'Post', 115, 'Crown', '2019-11-23',load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Crown.jpg'),'\Crown.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time, picture, picture_loc)
VALUES (8765, 'Phone Call', 116, 'Whitening', '2019-11-24', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Whitening.jpg'),'\Whitening.jpg');

INSERT INTO Appointment (appointment_id, booking_method, patient_id, treatment, appointment_date_time, picture, picture_loc)
VALUES (7654, 'Booked in Practice', 117, 'Root canal', '2019-11-25',load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\RootCanal.jpg'),'\RootCanal.jpg');





create table Payment (

	payment_id INT unsigned NOT NULL AUTO_INCREMENT,
	payment_type ENUM ('Card', 'Cash','Cheque') DEFAULT NULL, 
	amount DECIMAL (13,2),
	date_paid DATE NOT NULL,
	patient_id int unsigned NOT NULL,
	PRIMARY KEY (payment_id),
	FOREIGN KEY (patient_id) REFERENCES Patient(patient_id) ON UPDATE CASCADE ON DELETE CASCADE
	
);

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (111,'Card', (100.00), '2019-11-20');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (112,'Cheque', (75.00), '2019-11-21');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (113,'Card', (100.00), '2019-11-21');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (114,'Cash', (175.00), '2019-11-22');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (115,'Card', (125.00), '2019-11-23');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (116,'Cash', (85.00), '2019-11-24');

INSERT INTO Payment (patient_id,payment_type, amount, date_paid)
VALUES (117,'Card', (175.00), '2019-11-25');






create table Bill (
	bill_id INT unsigned NOT NULL AUTO_INCREMENT,
	amount DECIMAL(13,2) ,
	patient_id INT unsigned NOT NULL,
	date_issued DATE NOT NULL,
	PRIMARY KEY (bill_id),
	FOREIGN KEY (patient_id) REFERENCES Patient (patient_id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (111, (100.00), '2019-11-20');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (112, (75.00), '2019-11-20');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (113, (100.00), '2019-11-21');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (114, (175.00), '2019-11-21');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (115, (125.00), '2019-11-23');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (116, (85.00), '2019-11-24');

INSERT INTO Bill (patient_id, amount, date_issued)
VALUES (117, (175.00), '2019-11-25');




create table specialist (
	specialist_id VARCHAR(30) NOT NULL,
	specialist_name VARCHAR(30) NOT NULL,
	patient_id INT unsigned NOT NULL,
	specialist_treatment ENUM ('Crown','Root Canal') DEFAULT NULL,
	picture LONGBLOB DEFAULT NULL,
	picture_sp VARCHAR(50) DEFAULT NULL,
	PRIMARY KEY (specialist_id),
	FOREIGN KEY (patient_id) REFERENCES Patient (patient_id) ON UPDATE CASCADE ON DELETE CASCADE   
);


	INSERT INTO Specialist (specialist_id, specialist_name, patient_id, specialist_treatment, picture, picture_sp)
	VALUES (1001, 'Dr Johan', 115, 'Crown', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Crown.jpg'),'\Crown.jpg');
	
	INSERT INTO Specialist (specialist_id, specialist_name, patient_id, specialist_treatment, picture, picture_sp)
	VALUES (1002, 'Dr Dave', 114, 'Root canal', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\RootCanal.jpg'),'\RootCanal.jpg');
	
	INSERT INTO Specialist (specialist_id, specialist_name, patient_id, specialist_treatment, picture, picture_sp)
	VALUES (1003, 'Dr Aaron', 117, 'Root canal', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\RootCanal.jpg'),'\RootCanal.jpg');



create table Treatment (
	treatment_id INT unsigned NOT NULL,
	treatment_dr char(10) NOT NULL,
	patient_id INT unsigned NOT NULL,
	treatment_type ENUM ('Filling', 'Whitening', 'Extraction') DEFAULT NULL,
	picture LONGBLOB DEFAULT NULL, 
	picture_tr VARCHAR(50) DEFAULT NULL,
	PRIMARY KEY (treatment_id),
	FOREIGN KEY (patient_id) REFERENCES Patient (patient_id) ON UPDATE CASCADE ON DELETE CASCADE   
);

INSERT INTO Treatment (treatment_id, treatment_dr, patient_id, treatment_type, picture, picture_tr)
VALUES (111, 'Dr Doe', 111, 'Filling', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Filling.jpg'),'\Filling.jpg');

INSERT INTO Treatment (treatment_id, treatment_dr, patient_id, treatment_type, picture, picture_tr)
VALUES (112, 'Dr Doe', 112, 'Extraction', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Extraction.jpg'),'\Extraction.jpg');

INSERT INTO Treatment (treatment_id, treatment_dr, patient_id, treatment_type, picture, picture_tr)
VALUES (113, 'Dr Doe', 113, 'Filling', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Filling.jpg'),'\Filling.jpg');

INSERT INTO Treatment (treatment_id, treatment_dr, patient_id, treatment_type, picture, picture_tr)
VALUES (116, 'Dr Doe', 116, 'Whitening', load_file('C:\Users\joeyg\OneDrive\Desktop\Dentist\Whitening.jpg'),'\Whitening.jpg');


