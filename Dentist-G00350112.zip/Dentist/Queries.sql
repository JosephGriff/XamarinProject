SELECT * FROM APPOINTMENT;
SELECT * FROM BILL;
SELECT * FROM PATIENT;
SELECT * FROM PAYMENT;
SELECT * FROM SPECIALIST;
SELECT * FROM TREATMENT;



UPDATE BILL
SET amount = 120,
    date_issued = '2019-11-29'
WHERE patient_id = 111;

UPDATE PAYMENT
SET payment_type = 'Cash'
WHERE patient_id = 112;

UPDATE SPECIALIST
SET specialist_treatment = 'Crown'
WHERE specialist_id = 1003;



DELETE FROM PATIENT
WHERE patient_id = 112;

DELETE FROM APPOINTMENT
WHERE appointment_id = 8765;

DELETE FROM SPECIALIST
WHERE specialist_id = 1003;
